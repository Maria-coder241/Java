package hospede.java;

public class hospede {
    private String nome;
    private String cpf;

    public hospede(){
        this.nome = nome;
        this.cpf = cpf;
    }

    public String getNome(){ return this.nome; }
    public String getCpf(){ return this.cpf; }
}
